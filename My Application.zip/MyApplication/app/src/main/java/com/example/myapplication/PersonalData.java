package com.example.myapplication;

public class PersonalData {
    private String member_num;
    private String member_temp;
    private String member_humi;
    private String member_Soil_mos;
    private String member_Light;
    private String member_UploadTime;

    public String getMember_num() {
        return member_num;
    }

    public String getMember_temp() {
        return member_temp;
    }

    public String getMember_humi() {
        return member_humi;
    }
    public String getMember_Soil_mos() {
        return member_Soil_mos;
    }
    public String getMember_Light() {
        return member_Light;

    }public String getMember_UploadTime() {
        return member_UploadTime;
    }


    public void setMember_num(String member_num) {
        this.member_num = member_num;
    }

    public void setMember_temp(String member_temp) {
        this.member_temp = member_temp;
    }
    public void setMember_humi(String member_humi) {
        this.member_humi = member_humi;
    }
    public void setMember_Soil_mos(String member_Soil_mos) {
        this.member_Soil_mos = member_Soil_mos;
    }
    public void setMember_Light(String member_Light) {
        this.member_Light = member_Light;

    }public void setMember_UploadTime(String member_UploadTime) {
        this.member_UploadTime = member_UploadTime;
    }

}
